export default class FirebaseService {

    static list = (firestore, callback) => {

        let ref = firestore.collection('estudantes')
        ref.onSnapshot(
            (query) => {
                let estudantes = []
                query.forEach(
                    (doc) => {
                        const { Nome, Curso, IRA } = doc.data()
                        estudantes.push(
                            {
                                _id: doc.id,
                                Nome,
                                Curso,
                                IRA,
                            }
                        )//push
                    }//doc
                )//forEach

                //callback
                callback(estudantes)
            }//query

        )//onSnapshot

    }

    static delete = (firestore, callback, id) => {
        
        firestore.collection('estudantes').doc(id).delete()
        .then(
            () => callback('ok')
        )
        .catch(
            error => callback('nok')
        )
        
    }

    static create = (firestore, callback, estudante) => {
        firestore.collection('estudantes').add(
            {
                Nome: estudante.Nome,
                Curso: estudante.Curso,
                IRA: estudante.IRA
            }
        )
            .then(() => callback('ok'))
            .catch(error => callback('nok'))

    }

    static retrieve = (firestore, callback, id) => {
        firestore.collection('estudantes').doc(id).get()
            .then(
                (doc) => {
                    callback(
                        {
                            Nome: doc.data().Nome,
                            Curso: doc.data().Curso,
                            IRA: doc.data().IRA
                        }
                    )
                }
            )
            .catch(error => callback(null))

    }

    static edit = (firestore, callback, estudante, id) => {

        firestore.collection('estudantes').doc(id).set(
            {
                Nome: estudante.Nome,
                Curso: estudante.Curso,
                IRA: estudante.IRA
            }
        )
            .then(() => callback('ok'))
            .catch((error) => callback('nok'))

    }

}