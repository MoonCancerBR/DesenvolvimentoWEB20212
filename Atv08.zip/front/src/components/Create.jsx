import React, { Component } from 'react'

import FirebaseContext from '../utils/FirebaseContext'
import FirebaseService from '../services/FirebaseService'

const CreatePage = () => (
    <FirebaseContext.Consumer>
        {contexto => <Create firebase={contexto}/> }
    </FirebaseContext.Consumer>
)

class Create extends Component {
    constructor(props) {
        super(props)

        this.state = { Nome: '', Curso: '', IRA: '' }

        this.setNome = this.setNome.bind(this)
        this.setCurso = this.setCurso.bind(this)
        this.setIRA = this.setIRA.bind(this)
        this.handleSubmit = this.handleSubmit.bind(this)
        this.handleChange = this.handleChange.bind(this)
    }

    setNome(Nome) {
        this.setState({ Nome })
      }
      setCurso(Curso) {
        this.setState({ Curso })
      }
      setIRA(IRA) {
        this.setState({ IRA })
      }

    handleSubmit(e){
        e.preventDefault()

        const estudante = {
            Nome:this.state.Nome,
            Curso:this.state.Curso,
            IRA:this.state.IRA}
        
        FirebaseService.create(
            this.props.firebase.getFirestore(),
            (mensagem)=>{
                if(mensagem==='ok') console.log(`Estudante ${estudante.Nome} inserido!`)
            },
            estudante
            )

        this.setState({ Nome: '', Curso: '', IRA: '' })
    }

    handleChange(e) {
        switch (e.target.name) {
            case "Nome":
              this.setNome(e.target.value);
              break
            case "Curso":
              this.setCurso(e.target.value)
              break
            case "IRA":
              this.setIRA(e.target.value)
              break
            default:
              console.log("erro")
        }
    }

    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Criar Estudante</h3>
                <form onSubmit={this.handleSubmit}>

                    <div className="form-group">
                        <label htmlFor = "Nome">Nome: </label>
                        <input 
                        id = "Nome"
                        type="text" 
                        name="Nome" 
                        className="form-control" 
                        value={this.state.Nome} onChange={this.handleChange}
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor = "Curso">Curso: </label>
                        <input id = "Curso" name="Curso" type="text" className="form-control" 
                        value={this.state.Curso} onChange={this.handleChange}/>
                    </div>
                    <div className="form-group">
                        <label htmlFor='IRA'>IRA: </label>
                        <input id = "IRA" name = "IRA" type="text" className="form-control" 
                        value={this.state.IRA} onChange={this.handleChange}/>
                    </div>

                    <div className="form-group">
                        <input type="submit" value="Criar Estudante" className="btn btn-primary" />
                    </div>
                </form>

            </div>
        )
    }
}

export default CreatePage