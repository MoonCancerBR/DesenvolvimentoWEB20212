import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import FirebaseService from '../services/FirebaseService'

export default class TableRow extends Component {

    constructor(props){
        super(props)
        this.apagar = this.apagar.bind(this) 
    }

    apagar(id,Nome){

        let res = window.confirm(`Deseja apagar ${Nome}, id: ${id}?`)
        if(res){
            FirebaseService.delete(
                this.props.firebase.getFirestore(),
                (mensagem)=>{
                    if(mensagem==='ok')
                        console.log(`${Nome} apagado.`)
                },
                id
            )
        }
        
    }

    render() {
        return (
            <tr>
                <td>
                    {this.props.estudante._id}
                </td>
                <td>
                    {this.props.estudante.Nome}
                </td>
                <td>
                    {this.props.estudante.Curso}
                </td>
                <td>
                    {this.props.estudante.IRA}
                </td>
                <td style={{ textAlign: "center" }}>
                    <Link to={"/edit/"+this.props.estudante._id} className="btn btn-primary">
                        Editar
                    </Link>
                </td>
                <td style={{ textAlign: "center" }}>
                    <button onClick={()=> this.apagar(this.props.estudante._id,
                                                      this.props.estudante.Nome)} 
                    className="btn btn-danger">
                        Apagar
                    </button>
                </td>
            </tr>
        )
    }
}